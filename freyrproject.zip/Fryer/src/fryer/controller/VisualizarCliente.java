package fryer.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fryer.model.Cliente;
import fryer.persistence.DAOCliente;

@WebServlet("/VisualizarCliente")
public class VisualizarCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		Cliente c = new Cliente();
		c.setIdCliente(Integer.parseInt(request.getParameter("idCliente")));
		c.setNome(request.getParameter("nome"));
		c.setCpf(request.getParameter("cpf"));
		c.setSexo(request.getParameter("sexo"));
		
		DAOCliente dao = new DAOCliente();
		dao.atualizar(c);
		
		request.setAttribute("servMensagem", "Atualizado!");
		request.getRequestDispatcher("listacliente.jsp")
			.forward(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Integer id = Integer.parseInt(request.getParameter("id"));
		
		DAOCliente dao = new DAOCliente();
		request.setAttribute("cliente", dao.visualiza(id));
		request.getRequestDispatcher("visualiza-cliente.jsp").forward(request, response);
		
	}

}
