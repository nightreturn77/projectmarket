package fryer.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import fryer.model.Cliente;
import fryer.model.Contato;
import fryer.persistence.DAOCliente;
import fryer.persistence.DAOContato;
	
/**
 * Servlet implementation class CadastraClienteTest
 */
@WebServlet("/CadastraClienteTest")
public class CadastraClienteTest extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
		protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
   try{ 
		Cliente c = new Cliente();
		c.setNome(request.getParameter("nome"));
		c.setCpf(request.getParameter("cpf"));
		c.setSexo(request.getParameter("sexo"));
		Contato cont = new Contato();
		cont.setDdi(request.getParameter("ddi"));
		cont.setTelefone(request.getParameter("telefone"));
		cont.setCelular(request.getParameter("celular"));
		cont.setEmail(request.getParameter("email"));
		// DAO -> Cadastra o objeto Funcionario (func) no banco
		DAOCliente dao = new DAOCliente();
		dao.cadastrar(c);
		DAOContato daoc = new DAOContato();
		daoc.cadastrar(cont);
		// Caso tenha cadastrado, enviar um mensagem de Cadastrado
		// ${servMensagem} deve ser utilizado na p�gina jsp
		request.setAttribute("servMensagem", "Cadastrado!");
		
	}catch(Exception e) {
		request.setAttribute("servMensagem", "Erro!");
	}
	
	request.getRequestDispatcher("formclientetest.jsp")
		.forward(request, response);
		
		
		
		
	}
}

