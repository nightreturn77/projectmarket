package freyr.persistence;

import java.util.List;

import freyr.model.Categoria;

public class DAOCategoria extends DAO {

	public DAOCategoria(){
		super();
	}
	
	public void cadastrar(Categoria cat) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(cat); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<Categoria> getLista(){
		return entityManager.createQuery("FROM Categoria cat").getResultList();
	}
	
public Categoria visualiza(Integer id) {
		
		return entityManager.find(Categoria.class, id);
	}

	public void atualizar(Categoria categoria) { 
		entityManager.getTransaction().begin();
		entityManager.merge(categoria);
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}
	
}
