package freyr.persistence;

import java.util.List;

import freyr.model.Cliente;

public class DAOCliente extends DAO {

	public DAOCliente(){
		super();
	}
	
	public void cadastrar(Cliente c) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(c); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
	
	@SuppressWarnings("unchecked")
	public List<Cliente> getLista(){
		return entityManager.createQuery("FROM Cliente c").getResultList();
	}
	
public Cliente visualiza(Integer id) {
		
		return entityManager.find(Cliente.class, id);
	}

	public void atualizar(Cliente cliente) { 
		entityManager.getTransaction().begin();
		entityManager.merge(cliente);
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}
	
	
	
	
	
	
	
	
}
