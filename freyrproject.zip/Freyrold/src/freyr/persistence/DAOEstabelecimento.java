package freyr.persistence;

import java.util.List;

import freyr.model.Cliente;
import freyr.model.Estabelecimento;

public class DAOEstabelecimento extends DAO {

	public DAOEstabelecimento(){
		super();
	}
	
	public void cadastrar(Estabelecimento e) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(e); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
	
	@SuppressWarnings("unchecked")
	public List<Cliente> getLista(){
		return entityManager.createQuery("FROM Cliente c").getResultList();
	}
	
public Cliente visualiza(Integer id) {
		
		return entityManager.find(Cliente.class, id);
	}

	public void atualizar(Cliente cliente) { 
		entityManager.getTransaction().begin();
		entityManager.merge(cliente);
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}
	
	
	
	
	
	
	
	
}
