package freyr.persistence;

import freyr.model.Contato;

public class DAOContato extends DAO {

	public DAOContato(){
		super();
	}
	
	public void cadastrar(Contato cont) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(cont); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
}
