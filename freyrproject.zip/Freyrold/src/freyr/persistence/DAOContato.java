package freyr.persistence;

import java.util.List;


import freyr.model.Contato;

public class DAOContato extends DAO {

	public DAOContato(){
		super();
	}
	
	public void cadastrar(Contato cont) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(cont); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
	
	
	
	@SuppressWarnings("unchecked")
	public List<Contato> getLista(){
		return entityManager.createQuery("FROM Contato cont").getResultList();
	}
	
public Contato visualiza(Integer id) {
		
		return entityManager.find(Contato.class, id);
	}

	public void atualizar(Contato contato) { 
		entityManager.getTransaction().begin();
		entityManager.merge(contato);
		entityManager.getTransaction().commit();
		entityManager.close();
		
	}
	
}
