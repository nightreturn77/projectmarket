package freyr.persistence;

import freyr.model.Administrador;

public class DAOAdministrador extends DAO {

	public DAOAdministrador(){
		super();
	}
	
	public void cadastrar(Administrador adm) {
		entityManager.getTransaction().begin(); // inicia uma transa��o
		entityManager.persist(adm); // objeto a ser cadastrado
		entityManager.getTransaction().commit(); // executa o cadastro
		entityManager.close(); // fecha conex�o
	}
}
