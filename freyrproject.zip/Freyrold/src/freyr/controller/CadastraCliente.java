package freyr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freyr.model.Cliente;
import freyr.model.Contato;
import freyr.model.Endereco;
import freyr.model.Usuario;
import freyr.persistence.DAOCliente;
import freyr.persistence.DAOContato;
import freyr.persistence.DAOEndereco;
import freyr.persistence.DAOUsuario;
import freyr.util.User;
	
/**
 * Servlet implementation class CadastraClienteTest
 */
@WebServlet("/CadastraCliente")
public class CadastraCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) 
			throws ServletException, IOException {
		User.verifica(request, response);
   try{ 
	   	Usuario u = new Usuario();
	   	u.setLogin(request.getParameter("login"));
	   	u.setSenha(request.getParameter("senha"));
	   	Endereco end = new Endereco();
	   	end.setEndereco(request.getParameter("endereco"));
	   	end.setNumero(request.getParameter("numero"));
	   	end.setBairro(request.getParameter("bairro"));
	   	end.setCidade(request.getParameter("cidade"));
	   	end.setEstado(request.getParameter("estado"));
	   	end.setPais(request.getParameter("pais"));
	   	end.setCep(request.getParameter("cep"));
	   	end.setComplemento(request.getParameter("complemento"));
		Contato cont = new Contato();
		cont.setTelefone(request.getParameter("telefone"));
		cont.setEmail(request.getParameter("email"));
		Cliente c = new Cliente();
		c.setNome(request.getParameter("nome"));
		c.setCpf(request.getParameter("cpf"));
		c.setSexo(request.getParameter("sexo"));
		c.setContato(cont);
		c.setEndereco(end);
		c.setUsuario(u);
		
		// DAO -> Cadastra o objeto no banco
		DAOUsuario daou = new DAOUsuario();
		daou.cadastrar(u);
		DAOContato daoc = new DAOContato();
		daoc.cadastrar(cont);
		DAOEndereco daoe = new DAOEndereco();
		daoe.cadastrar(end);
		DAOCliente dao = new DAOCliente();
		dao.cadastrar(c);
		// Caso tenha cadastrado, enviar um mensagem de Cadastrado
		// ${servMensagem} deve ser utilizado na p�gina jsp
		request.setAttribute("servMensagem", "Cadastrado!");
		
	}catch(Exception e) {
		e.printStackTrace();
		request.setAttribute("servMensagem", "Erro!");
	}
	
	request.getRequestDispatcher("formclientetest.jsp")
		.forward(request, response);
		
		
		
		
	}
}

