package freyr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freyr.model.Categoria;
import freyr.model.Produtos;
import freyr.persistence.DAOCategoria;
import freyr.persistence.DAOProdutos;

/**
 * Servlet implementation class CadastraProdutos
 */
@WebServlet("/CadastraProdutos")
public class CadastraProdutos extends HttpServlet {
	private static final long serialVersionUID = 1L;

	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		try {
			
			
			Categoria cat = new Categoria();
			cat.setNomeCategoria(request.getParameter("nomeCategoria"));
			cat.setDescricao("Sem Descri��es");
			Produtos prod = new Produtos();
			prod.setNome(request.getParameter("nome"));
			prod.setDescricao(request.getParameter("descricao"));
			prod.setCor(request.getParameter("cor"));
			prod.setMarca(request.getParameter("marca"));
			prod.setModelo(request.getParameter("modelo"));
			prod.setValor(Double.parseDouble(request.getParameter("valor")));
			prod.setCategoria(cat);
			
			//DAO 
			DAOCategoria daoc = new DAOCategoria();
			daoc.cadastrar(cat);
			DAOProdutos dao = new DAOProdutos();
			dao.cadastrar(prod);
			request.setAttribute("servMensagem", "Cadastrado!");
			
		}catch(Exception e) { 
			e.printStackTrace();
			request.setAttribute("ServMensagem", "Erro!");
		}
		
		
		request.getRequestDispatcher("form-produtos.jsp")
			.forward(request, response);
		
	}

}
