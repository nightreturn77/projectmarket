package freyr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freyr.model.Cliente;
import freyr.model.Contato;
import freyr.persistence.DAOCliente;
import freyr.persistence.DAOContato;

@WebServlet("/VisualizarCliente")
public class VisualizarCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Contato cont = new Contato();
		cont.setTelefone(request.getParameter("telefone"));
		
		Cliente c = new Cliente();
		c.setIdCliente(Integer.parseInt(request.getParameter("idCliente")));
		c.setNome(request.getParameter("nome"));
		c.setCpf(request.getParameter("cpf"));
		c.setSexo(request.getParameter("sexo"));
		c.setContato(cont);
		
		
		DAOContato daoc = new DAOContato();
		daoc.cadastrar(cont);
		DAOCliente dao = new DAOCliente();
		dao.atualizar(c);
		
		request.setAttribute("servMensagem", "Atualizado!");
		request.getRequestDispatcher("listacliente.jsp")
			.forward(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		
		Integer id = Integer.parseInt(request.getParameter("id"));
		Integer id2 = Integer.parseInt(request.getParameter("id"));
		
		DAOContato daoc = new DAOContato();
		request.setAttribute("contato", daoc.visualiza(id2));
		request.getRequestDispatcher("visualiza-cliente.jsp").forward(request, response);
		DAOCliente dao = new DAOCliente();
		request.setAttribute("cliente", dao.visualiza(id));
		request.getRequestDispatcher("visualiza-cliente.jsp").forward(request, response);
		
	}

}
