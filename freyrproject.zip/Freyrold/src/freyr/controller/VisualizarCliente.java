package freyr.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import freyr.model.Cliente;
import freyr.model.Contato;
import freyr.model.Endereco;
import freyr.persistence.DAOCliente;
import freyr.persistence.DAOContato;
import freyr.persistence.DAOEndereco;
import freyr.util.User;

@WebServlet("/VisualizarCliente")
public class VisualizarCliente extends HttpServlet {
	private static final long serialVersionUID = 1L;

protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		Contato cont = new Contato();
		cont.setEmail(request.getParameter("email"));
		cont.setTelefone(request.getParameter("telefone"));
		
		Endereco end = new Endereco();
		end.setCep(request.getParameter("cep"));
		end.setEndereco(request.getParameter("endereco"));
		end.setBairro(request.getParameter("bairro"));
		end.setCidade(request.getParameter("cidade"));
		end.setEstado(request.getParameter("estado"));
		end.setNumero(request.getParameter("numero"));
		end.setPais(request.getParameter("pais"));
		end.setComplemento(request.getParameter("complemento"));
		
		Cliente c = new Cliente();
		c.setIdCliente(Integer.parseInt(request.getParameter("idCliente")));
		c.setNome(request.getParameter("nome"));
		c.setCpf(request.getParameter("cpf"));
		c.setSexo(request.getParameter("sexo"));
		c.setContato(cont);
		c.setEndereco(end);
		
		
		
		DAOEndereco daoe = new DAOEndereco();
		daoe.cadastrar(end);
		DAOContato daoc = new DAOContato();
		daoc.cadastrar(cont);
		DAOCliente dao = new DAOCliente();
		dao.atualizar(c);
		
		
		
		
		request.setAttribute("servMensagem", "Atualizado!");
		request.getRequestDispatcher("listacliente.jsp")
			.forward(request, response);
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		
		User.verifica(request, response);
		
		Integer id = Integer.parseInt(request.getParameter("id"));
		
		
		DAOCliente dao = new DAOCliente();
		request.setAttribute("cliente", dao.visualiza(id));
		request.getRequestDispatcher("listacliente.jsp").forward(request, response);
		
		
	}

}
