package freyr.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Cliente implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idCliente;
	private String nome;
	private String cpf;
	private String sexo;
	private String senha;
	
	public String getSenha() {
		return senha;
	}


	public void setSenha(String senha) {
		this.senha = senha;
	}


	@OneToOne
	@JoinColumn(name = "idEndereco")
	private Endereco endereco;
	
	@OneToOne
	@JoinColumn(name = "idContato")
	private Contato contato;
	
	@OneToMany(mappedBy = "cliente")
	private List<Mensagem> mensagem = new ArrayList<Mensagem>();
	
	@OneToMany(mappedBy = "cliente")
	private List<Reserva> reserva = new ArrayList<Reserva>();
	
	public Cliente() {
		
	}
	
	
	public List<Reserva> getReserva() {
		return reserva;
	}


	public void setReserva(List<Reserva> reserva) {
		this.reserva = reserva;
	}


	public String getSexo() {
		return sexo;
	}


	public void setSexo(String sexo) {
		this.sexo = sexo;
	}


	public Endereco getEndereco() {
		return endereco;
	}


	public void setEndereco(Endereco endereco) {
		this.endereco = endereco;
	}


	public Contato getContato() {
		return contato;
	}


	public void setContato(Contato contato) {
		this.contato = contato;
	}


	public List<Mensagem> getMensagem() {
		return mensagem;
	}


	public void setMensagem(List<Mensagem> mensagem) {
		this.mensagem = mensagem;
	}


	public Integer getIdCliente() {
		return idCliente;
	}
	public void setIdCliente(Integer idCliente) {
		this.idCliente = idCliente;
	}
	public String getNome() {
		return nome;
	}
	public void setNome(String nome) {
		this.nome = nome;
	}
	public String getCpf() {
		return cpf;
	}
	public void setCpf(String cpf) {
		this.cpf = cpf;
	}


	@Override
	public String toString() {
		return "Cliente [idCliente=" + idCliente + ", nome=" + nome + ", cpf=" + cpf + ", sexo=" + sexo + ", senha="
				+ senha + ", endereco=" + endereco + ", contato=" + contato + ", mensagem=" + mensagem + ", reserva="
				+ reserva + "]";
	}
	
	

}
