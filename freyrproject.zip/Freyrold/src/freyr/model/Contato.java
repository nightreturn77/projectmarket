package freyr.model;

import java.io.Serializable;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToOne;

@Entity
public class Contato implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idContato;
	private String telefone;
	private String email;
	
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "contato")
	private Cliente cliente;
	
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "contato")
	private Funcionario funcionario;
	
	@OneToOne(cascade = CascadeType.ALL, mappedBy = "contato")
	private Estabelecimento estabelecimento;
	
	
	public Contato() {
	
	}
	
	
	public Cliente getCliente() {
		return cliente;
	}


	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}


	public Funcionario getFuncionario() {
		return funcionario;
	}


	public void setFuncionario(Funcionario funcionario) {
		this.funcionario = funcionario;
	}


	public Estabelecimento getEstabelecimento() {
		return estabelecimento;
	}


	public void setEstabelecimento(Estabelecimento estabelecimento) {
		this.estabelecimento = estabelecimento;
	}


	public Integer getIdContato() {
		return idContato;
	}
	public void setIdContato(Integer idContato) {
		this.idContato = idContato;
	}

	public String getTelefone() {
		return telefone;
	}
	public void setTelefone(String telefone) {
		this.telefone = telefone;
	}

	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}


	@Override
	public String toString() {
		return "Contato [idContato=" + idContato + ", telefone=" + telefone + ", email=" + email + ", cliente="
				+ cliente + ", funcionario=" + funcionario + ", estabelecimento=" + estabelecimento + "]";
	}
	
		
}
