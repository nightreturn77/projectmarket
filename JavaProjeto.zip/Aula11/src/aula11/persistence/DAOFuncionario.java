package aula11.persistence;

import java.util.List;

import aula11.model.Funcionario;

public class DAOFuncionario extends DAO {

	public Funcionario visualiza(Integer id) {
		
		return entityManager.find(Funcionario.class, id);
	}
	
	public void cadastrar(Funcionario func) {
		entityManager.getTransaction().begin();
		entityManager.persist(func);
		entityManager.getTransaction().commit();
		entityManager.close(); 
	}
	
	public void atualizar(Funcionario funcionario) {
		entityManager.getTransaction().begin();
		entityManager.merge(funcionario);
		entityManager.getTransaction().commit();
		entityManager.close();
		}
	
	public void remove(Funcionario f) {
		entityManager.getTransaction().begin();
		f = entityManager.find(Funcionario.class, f.getId());
		entityManager.remove(f);
		entityManager.getTransaction().commit();
	}
	
	@SuppressWarnings("unchecked")
	public List<Funcionario> getLista(){
		return entityManager.createQuery("FROM Funcionario f").getResultList();
	}
	
}
