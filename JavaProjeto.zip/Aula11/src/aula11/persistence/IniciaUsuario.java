package aula11.persistence;

import aula11.model.Usuario;

public class IniciaUsuario {

	public static void main(String[] args) {
		Usuario u = new Usuario();
		u.setNome("Daniel");
		u.setSenha("123");
		
		DAOUsuario dao = new DAOUsuario();
		dao.cadastrar(u);
		

	}

}
