package aula11.persistence;

import java.util.List;

import aula11.model.Usuario;

public class DAOUsuario extends DAO {
	
	@SuppressWarnings("rawtypes")
	public boolean login(String nome, String senha){
		
		String sql = "from Usuario as u where u.nome=:vNome AND u.senha=:vSenha";
		
		javax.persistence.Query query = entityManager.createQuery(sql);
		
		query.setParameter("vNome", nome);
		query.setParameter("vSenha", senha);
		
		List result = query.getResultList();
		
		if(result.size()>0)
			return true;
		else
			return false;
		
	}
	
	public void cadastrar(Usuario u) {
		entityManager.getTransaction().begin();
		entityManager.persist(u);
		entityManager.getTransaction().commit();
		entityManager.close(); 
	}

}
