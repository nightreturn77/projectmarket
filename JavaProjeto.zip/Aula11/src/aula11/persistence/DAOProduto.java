package aula11.persistence;

import java.util.List;

import aula11.model.Produto;

public class DAOProduto extends DAO {

	public Produto visualiza(Integer id) {
		
		return entityManager.find(Produto.class, id);
	}
	
	public void cadastrar(Produto prod) {
		entityManager.getTransaction().begin();
		entityManager.persist(prod);
		entityManager.getTransaction().commit();
		entityManager.close(); 
	}
	
	public void atualizar(Produto prod) {
		entityManager.getTransaction().begin();
		entityManager.merge(prod);
		entityManager.getTransaction().commit();
		entityManager.close();
		}
	
	public void remove(Produto prod) {
		entityManager.getTransaction().begin();
		prod = entityManager.find(Produto.class, prod.getId());
		entityManager.remove(prod);
		entityManager.getTransaction().commit();
	}
	
	@SuppressWarnings("unchecked")
	public List<Produto> getLista(){
		return entityManager.createQuery("FROM Produto prod").getResultList();
	}
	
}
