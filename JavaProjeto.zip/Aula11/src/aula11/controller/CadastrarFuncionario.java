package aula11.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aula11.model.Funcionario;
import aula11.persistence.DAOFuncionario;
import aula11.util.User;


@WebServlet("/CadastrarFuncionario")
public class CadastrarFuncionario extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User.verifica(request, response);
		
		try {
			//Transforma os dados do formul�rio em um objeto Cliente
			//Sempre utilize get/set
			//request.getparameter -> Recupera um dado do formul�rio pelo name
			Funcionario func = new Funcionario();
			func.setNome(request.getParameter("nome"));
			func.setMatricula(request.getParameter("matricula"));
			func.setTelefone(request.getParameter("telefone"));
			func.setEmail(request.getParameter("email"));
			//DAO -> Cadastra o objeto Funcionario(func) no banco
			DAOFuncionario dao = new DAOFuncionario();
			dao.cadastrar(func);
			//Caso tenha cadastrado, enviar uma mensagem de Cadastrado
			//$[ServMensagem} deve ser utilizado na p�gina jsp
			request.setAttribute("servMensagem", "<h3>Cadastrado!</h3>");
		}catch(Exception e){
			request.setAttribute("servMensagem", "<h4>Erro!</h4>");
		}
		
		request.getRequestDispatcher("form-funcionario.jsp").forward(request, response);
	}

}
