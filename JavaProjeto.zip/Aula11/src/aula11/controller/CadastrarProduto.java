package aula11.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aula11.model.Produto;
import aula11.persistence.DAOProduto;
import aula11.util.User;


@WebServlet("/CadastrarProduto")
public class CadastrarProduto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User.verifica(request, response);
		
		try {
			//Transforma os dados do formul�rio em um objeto Cliente
			//Sempre utilize get/set
			//request.getparameter -> Recupera um dado do formul�rio pelo name
			Produto prod = new Produto();
			prod.setNome(request.getParameter("nome"));
			prod.setDescricao(request.getParameter("descricao"));
			prod.setPreco(Double.parseDouble(request.getParameter("preco")));
			//DAO -> Cadastra o objeto no banco
			DAOProduto dao = new DAOProduto();
			dao.cadastrar(prod);
			//Caso tenha cadastrado, enviar uma mensagem de Cadastrado
			//$[ServMensagem} deve ser utilizado na p�gina jsp
			request.setAttribute("servMensagem", "<h3>Cadastrado!</h3>");
		}catch(Exception e){
			request.setAttribute("servMensagem", "<h4>Erro!</h4>");
		}
		
		request.getRequestDispatcher("form-produto.jsp").forward(request, response);
	}

}
