package aula11.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aula11.model.Funcionario;
import aula11.persistence.DAOFuncionario;
import aula11.util.User;

@WebServlet("/VisualizarFuncionario")
public class VisualizarFuncionario extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException{
		User.verifica(request, response);
		
		Funcionario f = new Funcionario();
		f.setId(Integer.parseInt(request.getParameter("id")));
		f.setNome(request.getParameter("nome"));
		f.setMatricula(request.getParameter("matricula"));
		f.setTelefone(request.getParameter("telefone"));
		f.setEmail(request.getParameter("email"));
		
		DAOFuncionario dao = new DAOFuncionario();
		dao.atualizar(f);
		
		request.setAttribute("ServMensagem","Atualizado!" );
		request.getRequestDispatcher("lista-funcionario.jsp").forward(request, response);
		
	}
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User.verifica(request, response);
		
		Integer id = Integer.parseInt(request.getParameter("id"));
		
		DAOFuncionario dao = new DAOFuncionario();
		request.setAttribute("funcionario", dao.visualiza(id));
		request.getRequestDispatcher("visualiza-funcionario.jsp").forward(request, response);
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
