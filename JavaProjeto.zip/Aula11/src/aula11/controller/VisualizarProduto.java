package aula11.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import aula11.model.Produto;
import aula11.persistence.DAOProduto;
import aula11.util.User;

@WebServlet("/VisualizarProduto")
public class VisualizarProduto extends HttpServlet {
	private static final long serialVersionUID = 1L;

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		User.verifica(request, response);
		
		Produto prod = new Produto();
		prod.setId(Integer.parseInt(request.getParameter("id")));
		prod.setNome(request.getParameter("nome"));
		prod.setDescricao(request.getParameter("descricao"));
		prod.setPreco(Double.parseDouble(request.getParameter("preco")));
		
		DAOProduto dao = new DAOProduto();
		dao.atualizar(prod);
		
		request.setAttribute("ServMensagem","Atualizado!" );
		request.getRequestDispatcher("lista-produto.jsp").forward(request, response);
		
	}
	
protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	User.verifica(request, response);	
	
		Integer id = Integer.parseInt(request.getParameter("id"));
		
		DAOProduto dao = new DAOProduto();
		request.setAttribute("produto", dao.visualiza(id));
		request.getRequestDispatcher("visualiza-produto.jsp").forward(request, response);
		
		response.getWriter().append("Served at: ").append(request.getContextPath());
	}

}
