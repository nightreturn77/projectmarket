package fryer.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;
import javax.persistence.OneToOne;

@Entity
public class Administrador implements Serializable{
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idAdm;
	private String login;
	private String senha;
	
	@OneToMany(mappedBy = "administrador")
	private List<Estabelecimento> estabelecimento = new ArrayList<Estabelecimento>();
	
	@OneToMany(mappedBy = "administrador")
	private List<Funcionario> funcionario = new ArrayList<Funcionario>();
	
	@OneToOne(cascade = CascadeType.ALL, mappedBy= "administrador")
	private Cliente cliente;
	
	public Administrador() {
		
	}
	
	
	public Cliente getCliente() {
		return cliente;
	}


	public void setCliente(Cliente cliente) {
		this.cliente = cliente;
	}


	public List<Funcionario> getFuncionario() {
		return funcionario;
	}


	public void setFuncionario(List<Funcionario> funcionario) {
		this.funcionario = funcionario;
	}


	public List<Estabelecimento> getEstabelecimento() {
		return estabelecimento;
	}


	public void setEstabelecimento(List<Estabelecimento> estabelecimento) {
		this.estabelecimento = estabelecimento;
	}


	public Integer getIdAdm() {
		return idAdm;
	}
	public void setIdAdm(Integer idAdm) {
		this.idAdm = idAdm;
	}
	public String getLogin() {
		return login;
	}
	public void setLogin(String login) {
		this.login = login;
	}
	public String getSenha() {
		return senha;
	}
	public void setSenha(String senha) {
		this.senha = senha;
	}

	
}
