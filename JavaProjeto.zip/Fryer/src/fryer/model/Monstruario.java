package fryer.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Monstruario implements Serializable {
	private static final long serialVersionUID = 1L;
	
	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idMonst;
	
	@OneToMany(mappedBy = "monstruario")
	private List<Produtos> produtos = new ArrayList<Produtos>();
	
	public Monstruario() {
		
	}

	
	public List<Produtos> getProdutos() {
		return produtos;
	}


	public void setProdutos(List<Produtos> produtos) {
		this.produtos = produtos;
	}


	public Integer getIdMonst() {
		return idMonst;
	}

	public void setIdMonst(Integer idMonst) {
		this.idMonst = idMonst;
	}

	
}
