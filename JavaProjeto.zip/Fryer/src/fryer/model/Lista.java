package fryer.model;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Lista implements Serializable {
	private static final long serialVersionUID = 1L;

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private Integer idLIsta;

	@OneToMany(mappedBy = "lista")
	private List<Estoque> estoque = new ArrayList<Estoque>();
	
	@OneToMany(mappedBy = "lista")
	private List<Estabelecimento> estabelecimento = new ArrayList<Estabelecimento>();
	
	public Lista() {
		
	}
	
	public List<Estoque> getEstoque() {
		return estoque;
	}

	public void setEstoque(List<Estoque> estoque) {
		this.estoque = estoque;
	}

 	public List<Estabelecimento> getEstabelecimento() {
		return estabelecimento;
	}


	public void setEstabelecimento(List<Estabelecimento> estabelecimento) {
		this.estabelecimento = estabelecimento;
	}


	public Integer getIdLIsta() {
		return idLIsta;
	}

	public void setIdLIsta(Integer idLIsta) {
		this.idLIsta = idLIsta;
	}
	
	
}
